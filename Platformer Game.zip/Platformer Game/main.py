import pygame
from pygame.locals import *
from pygame import mixer
import pickle
import os
import button
from os import path

pygame.mixer.pre_init(44100, -16, 2, 512)
mixer.init()
pygame.init()

clock = pygame.time.Clock()
fps = 60
screen_width = 1000
screen_height = 1000
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Platformer')

#define font
font = pygame.font.SysFont('Bauhaus 93', 70)
font_end = pygame.font.SysFont('Bauhaus 93', 100)
font_score = pygame.font.SysFont('Bauhaus 93', 30)
font_health = pygame.font.SysFont('Bauhaus 93', 20)
font_buttons = pygame.font.SysFont('Calibri', 40)
font_instructions = pygame.font.SysFont('Calibri', 20)
font_countdown = pygame.font.SysFont('Comic Sans MS Bold', 50)
font_title = pygame.font.SysFont('Comic Sans MS Bold', 80)

#define game variables
tile_size = 50
game_over = 0
main_menu = True
level = 1
max_levels = 5
hay_score = 0
water_score = 0
score = 0
health = 100
player_hit_clock = 0
game_paused = False
leaderboard = False
last_count = pygame.time.get_ticks()
countdown = 45
time_taken = 0
i = 0
scores = list()
i2 = 0
name_asked = False
time = 45
buff = False
design = 0
customization = False

#define colours
white = (255, 255, 255)
green = (0, 255, 0)
red = (255, 0, 0)
black = (0, 0, 0)

#load images
sun_img = pygame.image.load('img/sun.png')
bg_img = pygame.image.load('img/sky.png')
restart_img = pygame.image.load('img/restart_btn.png')
start_img = pygame.image.load('img/start_btn.png')
customization_img = pygame.image.load('img/customization_btn.png')
exit_img = pygame.image.load('img/exit_btn.png')
clock_img = pygame.image.load('img/clock.png')
horse0_img = pygame.image.load('img/horse1des0.png')
horse1_img = pygame.image.load('img/horse1des1.png')
horse2_img = pygame.image.load('img/horse1des2.png')
horse3_img = pygame.image.load('img/horse1des3.png')
resume_img = pygame.image.load("img/button_resume.png").convert_alpha()
quit_img = pygame.image.load("img/button_quit.png").convert_alpha()
save_img = pygame.image.load("img/save_button.png").convert_alpha()
load_img = pygame.image.load('img/load_btn.png').convert_alpha()

#load sounds
pygame.mixer.music.load('img/music.wav')
pygame.mixer.music.play(-1, 0.0, 5000)
coin_fx = pygame.mixer.Sound('img/coin.wav')
coin_fx.set_volume(0.5)
jump_fx = pygame.mixer.Sound('img/jump.wav')
jump_fx.set_volume(0.5)
game_over_fx = pygame.mixer.Sound('img/game_over.wav')
game_over_fx.set_volume(0.5)
damage_fx = pygame.mixer.Sound('img/game_over.wav')
damage_fx.set_volume(0.5)

#draw_text
def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    screen.blit(img, (x, y))

#function to reset level
def reset_level(level):
    player.reset(100, screen_height - 130)
    blob_group.empty()
    platform_group.empty()
    hay_group.empty()
    water_group.empty()
    lake_group.empty()
    exit_group.empty()
    carrot_group.empty()
    
    #load in level data and create world
    if path.exists(f'level{level}_data'):
        pickle_in = open(f'level{level}_data', 'rb')
        world_data = pickle.load(pickle_in)
    world = World(world_data)
	#create dummies for showing the score
    score_hay = Hay(40, 25)
    hay_group.add(score_hay)
    score_water = Water(185, 25)
    water_group.add(score_water)
    return world


class Button():
    def __init__(self, x, y, image):
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.clicked = False

    def draw(self):
        action = False

        #get mouse position
        pos = pygame.mouse.get_pos()

        #check mouseover and clicked conditions
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                action = True
                self.clicked = True

        if pygame.mouse.get_pressed()[0] == 0:
            self.clicked = False

        #draw button
        screen.blit(self.image, self.rect)

        return action


class Player():
    global self
    def __init__(self, x, y):
        self.reset(x, y)

    def update(self, game_over):
        dx = 0
        dy = 0
        walk_cooldown = 5
        col_thresh = 20
        hit_clock = 500
        time_now = pygame.time.get_ticks()  
        global health
        global player_hit_clock

        if game_over == 0 and not game_paused and leaderboard == False:
            if buff == False:
                #get keypresses
                key = pygame.key.get_pressed()
                if key[pygame.K_SPACE] and self.jumped == False and self.in_air == False:
                    jump_fx.play()
                    self.vel_y = -15
                    self.jumped = True
                if key[pygame.K_SPACE] == False:
                    self.jumped = False
                if key[pygame.K_LEFT]:
                    dx -= 5
                    self.counter += 1
                    self.direction = -1
                if key[pygame.K_RIGHT]:
                    dx += 5
                    self.counter += 1
                    self.direction = 1
                if key[pygame.K_LEFT] == False and key[pygame.K_RIGHT] == False:
                    self.counter = 0
                    self.index = 0
                    if self.direction == 1:
                        self.image = self.images_right[self.index]
                    if self.direction == -1:
                        self.image = self.images_left[self.index]
            if buff == True:
                #get keypresses
                key = pygame.key.get_pressed()
                if key[pygame.K_SPACE] and self.jumped == False and self.in_air == False:
                    jump_fx.play()
                    self.vel_y = -20
                    self.jumped = True
                if key[pygame.K_SPACE] == False:
                    self.jumped = False
                if key[pygame.K_LEFT]:
                    dx -= 8
                    self.counter += 1
                    self.direction = -1
                if key[pygame.K_RIGHT]:
                    dx += 8
                    self.counter += 1
                    self.direction = 1
                if key[pygame.K_LEFT] == False and key[pygame.K_RIGHT] == False:
                    self.counter = 0
                    self.index = 0
                    if self.direction == 1:
                        self.image = self.images_right[self.index]
                    if self.direction == -1:
                        self.image = self.images_left[self.index]
                draw_text('HEALTH++     SPEED +3     JUMP BOOST +5', pygame.font.SysFont('Roboto', 40), white, 210, 80)

            #handle animation
            if self.counter > walk_cooldown:
                self.counter = 0    
                self.index += 1
                if self.index >= len(self.images_right):
                    self.index = 0
                if self.direction == 1:
                    self.image = self.images_right[self.index]
                if self.direction == -1:
                    self.image = self.images_left[self.index]

            #add gravity
            self.vel_y += 1
            if self.vel_y > 10:
                self.vel_y = 10
            dy += self.vel_y

            #check for collision
            self.in_air = True
            for tile in world.tile_list:
                #check for collision in x direction
                if tile[1].colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                    dx = 0
                #check for collision in y direction
                if tile[1].colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                    #check if below the ground i.e. jumping
                    if self.vel_y < 0:
                        dy = tile[1].bottom - self.rect.top
                        self.vel_y = 0
                    #check if above the ground i.e. falling
                    elif self.vel_y >= 0:
                        dy = tile[1].top - self.rect.bottom
                        self.vel_y = 0
                        self.in_air = False

            #check for collision with enemies
            if pygame.sprite.spritecollide(self, blob_group, False):                            
                if time_now > player_hit_clock:
                    health -= 25
                    player_hit_clock = time_now + hit_clock
                    game_over_fx.play()
                if health <= 0:
                    game_over = -1
                    game_over_fx.play()

            #check for collision with lake
            if pygame.sprite.spritecollide(self, lake_group, False):
                health -= 50
                game_over_fx.play()
                player.reset(100, screen_height - 130)
                if health <= 0:
                    game_over = -1
                    game_over_fx.play()
           
            draw_text(str(health) + '%', font_health, white, 790 , 14)

            #check for collision with exit
            if pygame.sprite.spritecollide(self, exit_group, False):
                if hay_score == 3 and water_score == 3:
                    game_over = 1
           
            #notofies player to collect all the hay if they have not
            if pygame.sprite.spritecollide(self, exit_group, False):
                if hay_score != 3 or water_score != 3:
                    draw_text('You must collect all hay and water!', pygame.font.SysFont('Roboto', 40), white, 260, 120)

            #check for collision with platforms
            for platform in platform_group:
                #collision in the x direction
                if platform.rect.colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                    dx = 0
                #collision in the y direction
                if platform.rect.colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                    #check if below platform
                    if abs((self.rect.top + dy) - platform.rect.bottom) < col_thresh:
                        self.vel_y = 0
                        dy = platform.rect.bottom - self.rect.top
                    #check if above platform
                    elif abs((self.rect.bottom + dy) - platform.rect.top) < col_thresh:
                        self.rect.bottom = platform.rect.top - 1
                        self.in_air = False
                        dy = 0
                    #move sideways with the platform
                    if platform.move_x != 0:
                        self.rect.x += platform.move_direction

            #update player coordinates
            self.rect.x += dx
            self.rect.y += dy

        elif game_over == -1:
            self.image = self.dead_image
            draw_text('GAME OVER!', font_end, red, 230, 450)
            if self.rect.y > 200:
                self.rect.y -= 5

        if game_paused == False and leaderboard == False:
            #draw player onto screen
            screen.blit(self.image, self.rect)
            
        return game_over

    def reset(self, x, y):
        global design
        self.images_right = []
        self.images_left = []
        self.index = 0
        self.counter = 0
        for num in range(1, 5):
            img_right = pygame.image.load(f'img/horse{num}des{design}.png')
            img_right = pygame.transform.scale(img_right, (66, 60))
            img_left = pygame.transform.flip(img_right, True, False)
            self.images_right.append(img_right)
            self.images_left.append(img_left)
        self.dead_image = pygame.image.load('img/ghost.png')
        self.image = self.images_right[self.index]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.vel_y = 0
        self.jumped = False
        self.direction = 0
        self.in_air = True


class HealthBar():
    def __init__(self, x, y, w, h, max_hp):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.hp = max_hp
        self.max_hp = max_hp

    def draw(self, surface):

        #calculate health ratio
        ratio = self.hp / self.max_hp
        pygame.draw.rect(surface, "red", (self.x, self.y, self.w, self.h))
        pygame.draw.rect(surface, "green", (self.x, self.y, self.w * ratio, self.h))

health_bar = HealthBar(785, 15, 200, 20, 100)


class World():
    def __init__(self, data):
        self.tile_list = []

        #load images
        dirt_img = pygame.image.load('img/dirt.png')
        grass_img = pygame.image.load('img/grass.png')

        row_count = 0
        for row in data:
            col_count = 0
            for tile in row:
                if tile == 1:
                    img = pygame.transform.scale(dirt_img, (tile_size, tile_size))
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 2:
                    img = pygame.transform.scale(grass_img, (tile_size, tile_size))
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 3:
                    blob = Enemy(col_count * tile_size, row_count * tile_size + 10)
                    blob_group.add(blob)
                if tile == 4:
                    platform = Platform(col_count * tile_size, row_count * tile_size, 1, 0)
                    platform_group.add(platform)
                if tile == 5:
                    platform = Platform(col_count * tile_size, row_count * tile_size, 0, 1)
                    platform_group.add(platform)
                if tile == 6:
                    lake = Lake(col_count * tile_size, row_count * tile_size + (tile_size // 2))
                    lake_group.add(lake)
                if tile == 7:
                    hay = Hay(col_count * tile_size + (tile_size // 2), row_count * tile_size + 30)
                    hay_group.add(hay)
                if tile == 8:
                    exit = Exit(col_count * tile_size, row_count * tile_size - 10)
                    exit_group.add(exit)
                if tile == 9:
                    water = Water(col_count * tile_size + (tile_size // 2), row_count * tile_size + 30)
                    water_group.add(water)
                if tile == 10:
                    carrot = Carrot(col_count * tile_size + (tile_size // 2), row_count * tile_size + 30)
                    carrot_group.add(carrot)
                col_count += 1
            row_count += 1

    def draw(self):
        for tile in self.tile_list:
            screen.blit(tile[0], tile[1])           


class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        if not game_paused:
            pygame.sprite.Sprite.__init__(self)
            self.image = pygame.image.load('img/flies.png')
            self.rect = self.image.get_rect()
            self.rect.x = x
            self.rect.y = y
            self.move_direction = 1
            self.move_counter = 0

    def update(self):
        if not game_paused:
            self.rect.x += self.move_direction
            self.move_counter += 1
            if abs(self.move_counter) > 50:
                self.move_direction *= -1
                self.move_counter *= -1


class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, move_x, move_y):
        pygame.sprite.Sprite.__init__(self)
        img = pygame.image.load('img/platform.png')
        self.image = pygame.transform.scale(img, (tile_size, tile_size // 2))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.move_counter = 0
        self.move_direction = 1
        self.move_x = move_x
        self.move_y = move_y

    def update(self):
        if game_paused == False and leaderboard == False:
            self.rect.x += self.move_direction * self.move_x
            self.rect.y += self.move_direction * self.move_y
            self.move_counter += 1
            if abs(self.move_counter) > 50:
                self.move_direction *= -1
                self.move_counter *= -1


class Lake(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        img = pygame.image.load('img/lake.png')
        self.image = pygame.transform.scale(img, (tile_size, tile_size // 2))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


class Hay(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        img = pygame.image.load('img/hay.png')
        self.image = pygame.transform.scale(img, (tile_size, tile_size))
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)


class Carrot(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        img = pygame.image.load('img/carrot.png')
        self.image = pygame.transform.scale(img, (tile_size, tile_size))
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)


class Water(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        img = pygame.image.load('img/water.png')
        self.image = pygame.transform.scale(img, (tile_size, tile_size))
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)


class Exit(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        img = pygame.image.load('img/exit.png')
        self.image = pygame.transform.scale(img, (tile_size, int(tile_size * 1.5)))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

player = Player(100, screen_height - 130)
blob_group = pygame.sprite.Group()
platform_group = pygame.sprite.Group()
lake_group = pygame.sprite.Group()
hay_group = pygame.sprite.Group()
carrot_group = pygame.sprite.Group()
exit_group = pygame.sprite.Group()
water_group = pygame.sprite.Group()

#create dummy hay for showing the score
score_hay = Hay(40, 25)
hay_group.add(score_hay)
#create dummy water for showing the score
score_water = Water(185, 25)
water_group.add(score_water)

#load in level data and create world
if os.path.exists(f'level{level}_data'):
    pickle_in = open(f'level{level}_data', 'rb')
    world_data = pickle.load(pickle_in)
world = World(world_data)

#create buttons
restart_button = Button(screen_width // 2 - 60, screen_height // 2 + 130, restart_img)
start_button = Button(screen_width // 2 - 350, 425, start_img)
exit_button = Button(screen_width // 2 + 105, 425, exit_img)
horse0_choice = Button(200 - 40, 600, horse0_img)
horse1_choice = Button(400 - 40, 600, horse1_img)
horse2_choice = Button(600 - 40, 600, horse2_img)
horse3_choice = Button(800 - 40, 600, horse3_img)
customization_button = Button(12, 12, customization_img)
load_button = button.Button(395, 270, load_img, 3)
resume_button = button.Button(screen_width // 2 - 160, 230, resume_img, 1)
save_button = button.Button(screen_width // 2 - 160, 430, save_img, 1)
quit_button = button.Button(screen_width // 2 - 160, 630, quit_img, 1)


run = True
while run:

    clock.tick(fps)
    screen.blit(bg_img, (0, 0))
    screen.blit(sun_img, (100, 100))

    #customization
    if customization == True:
        if horse0_choice.draw():
            design = 0
            customization = False
        if horse1_choice.draw():
            design = 1
            customization = False
        if horse2_choice.draw():
            design = 2
            customization = False
        if horse3_choice.draw():
            design = 3
            customization = False   
        draw_text('Note: skin will be applied when your character is reset', pygame.font.SysFont('Roboto', 40), white, 140, 740)
    
    # check if leaderboard is hit
    # load leaderboard
    if game_paused == False and main_menu == False and leaderboard == True :
        screen.fill('light blue')
        if i == 0:
            rank = 1
            scoreList = []
            a = 0
            i3 = 0
            while a < 5:
                scoreList.append(str(rank) + '. 0')
                rank += 1
                a += 1
            rank = 1
            
            if os.path.exists('leaderboard.txt'):
                scores.clear()
                # load high score
                if os.path.exists('leaderboard.txt'):
                    filename = 'leaderboard.txt'
                    with open(filename) as fin:
                        for line in fin:
                            scores.append(line.split())
                    y = sorted(scores, key = lambda x: float(x[0]), reverse=False)
                    for eachline in y[:5]: 
                        scoreList[i3] = (str(rank) + '. ' + " ".join(eachline))
                        rank += 1
                        i3 += 1
        a = 0
        i += 1
        rank = 1
        i3 = 0

        # display scores
        text1 = font_countdown.render(str(scoreList[0]), True, 'black')
        text2 = font_countdown.render(str(scoreList[1]), True, 'black')
        text3 = font_countdown.render(str(scoreList[2]), True, 'black')
        text4 = font_countdown.render(str(scoreList[3]), True, 'black')
        text5 = font_countdown.render(str(scoreList[4]), True, 'black')
        text6 = font_title.render('Leaderboard', True, 'black')
        textRect6 = text6.get_rect(center = (screen_width // 2, screen_height // 2 - 180)) 
        textRect1 = text1.get_rect(center = (screen_width // 2, screen_height // 2 - 110)) 
        textRect2 = text2.get_rect(center = (screen_width // 2, screen_height // 2 - 60))               
        textRect3 = text3.get_rect(center = (screen_width // 2, screen_height // 2 - 10))
        textRect4 = text4.get_rect(center = (screen_width // 2, screen_height // 2 + 40))
        textRect5 = text5.get_rect(center = (screen_width // 2, screen_height // 2 + 90))
        screen.blit(text1,textRect1)
        screen.blit(text2,textRect2)
        screen.blit(text3,textRect3)
        screen.blit(text4,textRect4)
        screen.blit(text5,textRect5)
        screen.blit(text6,textRect6)

    if leaderboard == False:
        i = 0

    #check if game is paused
    if main_menu == False and leaderboard == False and game_paused == True: 
        #draw pause screen buttons
        screen.fill('light green')
        if resume_button.draw(screen):
            game_paused = False
        if quit_button.draw(screen):
            run = False
        if save_button.draw(screen):
            save = open(('game_save.txt'), 'w')
            save.write(str(level) + '\n' +  str(health) + '\n' + str((time_taken)))
            save.close()

    if main_menu == True:
        if customization_button.draw():
            customization = True
        if exit_button.draw():
            run = False
        if start_button.draw():
            main_menu = False
        if load_button.draw(screen):
            if os.path.exists('game_save.txt'):
                load = open('game_save.txt', 'r')
                load_data = load.readlines()
                level = int(load_data[0].strip('\n'))
                #reset level
                world_data = []
                world = reset_level(level)
                game_over = 0
                score = 0
                countdown = 45
                health = 100
                time_taken = int(load_data[2])
    else:
        if game_paused == False and leaderboard == False and main_menu == False:
            customization = False
            world.draw()
            if game_over == 0:
                blob_group.update()
                platform_group.update()
            #update score
            #check if hay has been collected
            if pygame.sprite.spritecollide(player, hay_group, True):
                hay_score += 1
                coin_fx.play()
            draw_text('X ' + str(hay_score) + '/3', font_score, white, 75, 10)
            #check if water has been collected
            if pygame.sprite.spritecollide(player, water_group, True):
                water_score += 1
                coin_fx.play()
            score = hay_score + water_score
            draw_text('X ' + str(water_score) + '/3', font_score, white, 220, 10)
            #check if carrot has been collected
            if pygame.sprite.spritecollide(player, carrot_group, True):
                health_loss = 100 - health
                coin_fx.play()
                health = health + health_loss
                buff = True   
            
        if game_paused == False and leaderboard == False and main_menu == False:
            blob_group.draw(screen)
            platform_group.draw(screen)
            lake_group.draw(screen)
            hay_group.draw(screen)
            carrot_group.draw(screen)
            exit_group.draw(screen)
            water_group.draw(screen)
            screen.blit(clock_img, (415, -8))

        #draw health bar
        if game_paused == False and leaderboard == False and main_menu == False:
            health_bar.hp = health
            health_bar.draw(screen)

        game_over = player.update(game_over)

        #if player has died
        if game_over == -1:
            if restart_button.draw():
                world_data = []
                world = reset_level(level)
                game_over = 0
                hay_score = 0
                water_score = 0
                score = 0
                health = 100
                countdown = 45
                buff = False

        #countdown and instructions
        if game_paused == False and main_menu == False and leaderboard == False:
            count_timer = pygame.time.get_ticks()
            if countdown >= 0:
                draw_text(str(countdown), font_countdown, white, 480, screen_height // 2 - 490)
            if count_timer - last_count > 1000:
                countdown -= 1
                last_count = count_timer
                time_taken += 1
            if countdown == 0:
                game_over = -1
            draw_text('Tab = Leaderboard', font_instructions, white, 10, 975)
            draw_text('Esc = Menu', font_instructions, white, 200, 975)   
            draw_text('Movement = ← →', font_instructions, white, 660, 975)     
            draw_text('Jump = Spacebar', font_instructions, white, 850, 975)       

        #if player has completed the level
        if game_over == 1:
            #reset game and go to next level
            level += 1
            if level <= max_levels:
                #reset level
                world_data = []
                world = reset_level(level)
                hay_score = 0
                water_score = 0
                game_over = 0
                health = 100
                countdown = 45
                buff = False
            else:
                player_name = ""
                while name_asked == False:
                    screen.fill('white')
                    win = font_title.render("You Win!", True, 'Green')
                    question = font_title.render("Enter a username: ", True, 'Black')
                    input_surface = font_countdown.render(player_name, True, 'Black')
                    screen.blit(win, (375, screen_height // 2 - 200))
                    screen.blit(question, (240, screen_height // 2 - 100))
                    screen.blit(input_surface, (screen_width // 2 - 325, screen_height // 2 + 25))

                    pygame.display.flip()
            
                    for event in pygame.event.get():
                        if event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_BACKSPACE:
                                player_name = player_name[:-1]
                            elif event.key == pygame.K_RETURN:
                                name_asked = True
                            else:
                                player_name += event.unicode
                        if event.type == pygame.QUIT:
                            pygame.quit()
                        
                        pygame.display.update()

                if i2 == 0:
                    scores.clear()
                    with open ('leaderboard.txt', 'a') as file:
                        file.write(str(time_taken) + ' seconds' + " : " + player_name + "\n")
                        i2 += 1

                if name_asked == True:
                    screen.fill('light blue')
                    if i == 0:
                        rank = 1
                        scoreList = []
                        a = 0
                        i3 = 0
                        while a < 5:
                            scoreList.append(str(rank) + '. 0')
                            rank += 1
                            a += 1
                        rank = 1
                            
                        if os.path.exists('leaderboard.txt'):
                            scores.clear()
                            # load high score
                            if os.path.exists('leaderboard.txt'):
                                filename = 'leaderboard.txt'
                                with open(filename) as fin:
                                    for line in fin:
                                        scores.append(line.split())
                                y = sorted(scores, key = lambda x: float(x[0]), reverse=False)
                                for eachline in y[:5]: 
                                    scoreList[i3] = (str(rank) + '. ' + " ".join(eachline))
                                    rank += 1
                                    i3 += 1
                    a = 0
                    i += 1
                    rank = 1
                    i3 = 0

                    # display scores
                    text1 = font_countdown.render(str(scoreList[0]), True, 'black')
                    text2 = font_countdown.render(str(scoreList[1]), True, 'black')
                    text3 = font_countdown.render(str(scoreList[2]), True, 'black')
                    text4 = font_countdown.render(str(scoreList[3]), True, 'black')
                    text5 = font_countdown.render(str(scoreList[4]), True, 'black')
                    text6 = font_title.render('Leaderboard', True, 'black')
                    textRect6 = text6.get_rect(center = (screen_width // 2, screen_height // 2 - 180)) 
                    textRect1 = text1.get_rect(center = (screen_width // 2, screen_height // 2 - 110)) 
                    textRect2 = text2.get_rect(center = (screen_width // 2, screen_height // 2 - 60))               
                    textRect3 = text3.get_rect(center = (screen_width // 2, screen_height // 2 - 10))
                    textRect4 = text4.get_rect(center = (screen_width // 2, screen_height // 2 + 40))
                    textRect5 = text5.get_rect(center = (screen_width // 2, screen_height // 2 + 90))
                    screen.blit(text1,textRect1)
                    screen.blit(text2,textRect2)
                    screen.blit(text3,textRect3)
                    screen.blit(text4,textRect4)
                    screen.blit(text5,textRect5)
                    screen.blit(text6,textRect6)

                    if restart_button.draw():
                        level = 1
                        #reset level
                        world_data = []
                        world = reset_level(level)
                        game_over = 0
                        hay_score = 0
                        water_score = 0
                        score = 0
                        health = 100
                        countdown = 45
                        buff = False
                        time_taken = 0
                        i2 = 0
                        name_asked = False

  # event handler
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                if game_paused:
                    game_paused = False
                else:
                    game_paused = True
            if event.key == pygame.K_TAB:
                if leaderboard:
                    leaderboard = False
                else:
                    leaderboard = True
        if event.type == pygame.QUIT:
            run = False


    pygame.display.update()

pygame.quit()
